import tkinter as tk
from tkinter import PhotoImage

window = tk.Tk()
frame1 = tk.Frame(window)
frame1.pack()
windowWidth = 600
windowHeight = 800
window.minsize(windowWidth,windowHeight)    # Setter størrelsen.

overskrift = tk.Label(frame1,text="Overskrift",font=("Arial",30))
overskrift.grid(row=1,column=1)

# 1) Lager en ramme som canvas kan ligge inni
canvas_frame = tk.Frame(window)
canvas_frame.pack()

# 2) Lager en header med bildet pacman
#header = tk.Canvas(canvas_frame,width = windowWidth, height = 200)
#header.pack()
#pacman_logo = PhotoImage(file="pacman_logo_small.png")
#logo = header.create_image(windowWidth/2,90,image=pacman_logo)



# Lager en NY ramme som selve spill-canvas kan ligge inni.
frame2 = tk.Frame(window)
frame2.pack()
canvas = tk.Canvas(frame2,width=windowWidth,height=600,background="black")
canvas.pack()
canvas.create_rectangle(10,10,50,50,fill="chartreuse",
outline="blue",width=5, tags="firkant")
canvas.create_oval(50,10,90,50,outline="white")

# 3) Lag pacman-klassen som har informasjonen om pacman: xpos, ypos, retning etc.

# 4) Animer pacman

# 5) Teleporter pacman gjennom veggene

# 6) Tastaturkontroll med piltaster.

# 7) Lag frukt-klassen og underklassene. Frukt skal dukke opp tilfeldig.

def tegn_ball():
    """Tegner en ball i canvas"""


# avsluttknapp
footer = tk.Frame(window)
footer.pack()
avslutt = tk.Button(footer,text="Avslutt")
fjern_firkant = tk.Button(footer,text="Fjern firkant")
avslutt.pack()
fjern_firkant.pack()

def handle_avslutt(event):
    window.destroy()

def handle_firkant(event):
    canvas.delete("firkant")
    
avslutt.bind("<Button-1>",handle_avslutt)
fjern_firkant.bind("<Button-1>",handle_firkant)


window.mainloop()
